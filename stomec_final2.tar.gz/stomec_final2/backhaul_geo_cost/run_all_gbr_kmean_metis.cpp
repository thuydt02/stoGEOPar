//
//  run_all.cpp
//  
//
//  Created by Thuy Do on 2/17/19.
//
//
//This code is to run all alg :KG, GG, GBR (3 options of initializeF)
//and compute costs

#include <cstdlib>
#include <stdexcept>
#include <sys/stat.h>
#include <sys/types.h>
#include <iostream>
#include <sstream>
#include <random>

#include "algorithms.h"
#include "tFile.h"
#include "cost.h"

using namespace std;

//configuration, see algorithms for meanings
int N;
int M = 100;
int n_iteration = 4000;
//double geo_diameter_list[] = {3}; // here 1 unit = 1.23 km realistically 

std::string base_folder = "../configuration11/";
std::string input_folder = base_folder + "input/";

std::string output_folder = base_folder + "output/"; 
std::string evaluation_folder = base_folder + "evaluation/";

char* mu_delimiter = new char(',');
std::string mu_file = input_folder + "TimeVaryingWeights_packets_AllBS.MeanSD";

char* z_delimiter = new char('\n');

std::string tv_weight_file = input_folder + "TimeVaryingWeights_packets_AllBS.csv";

std::string grid_file = input_folder + "topology.xy";  //it is 2D coordinate points.
char* grid_delimiter = new char(',');

std::string z_metis_fname = "mean_packets_AllBS_v2.graph.part.";
std::string z_kmean_fname = "z_kmean_K";

int n_kappa_ratio = 2;
double kappa_ratio[] = {1, 1.3};

int n_gamma_ratio = 5;
double gamma_ratio[] = {.1,.3, .5, .7, .9};//gg
double alist[] = {0,.1, .2, .3, .4, .5, .6, .7, .8, .9, 1};
int num_a = 11;

double sum_mu;

algorithms alg; // to run all algs
cost costs;     // to compute all costs

//for ease

std::string sN;
std::string sM;

void run_RndPartition(){

    std::cout <<"\nrunning RandomPartition of " << N << " vertices in ";
    std::cout <<M <<" clusters";
    
    int* z = alg.RandomPartition();

    for (int i = 0; i < N; i++)
	std::cout <<"\n" <<z[i];

    std::cout <<"\nvertices cannot be put in any cluster: ";

	for (int i = 0; i < N; i++){
		if (z[i] == -1)
			std::cout <<i << " ";
	}

    std::string z_file = output_folder + "z_RndPartition_N" + sN + "_M" + sM + ".csv";
    std::cout <<"\nSaving z into " << z_file << "\n";
    tFile::saveIntFile(z, N, z_file, z_delimiter[0]);
    if (z != NULL) delete[] z;
}


void run_localSearchPartition(std::string initFile, std::string fout_term, double a){
    
    
    double* kappa = new double[M];            
    //std::cout << "kappa = " << kappa ;
    
    double* gamma = new double[M];        
        
        std::ostringstream a_str;
        a_str << a;
                        
        for (int i = 0; i < n_kappa_ratio; i++){

            for (int s1 = 0; s1 < M; s1++){
                kappa[s1] = kappa_ratio[i] * sum_mu / (double) M;

            }
            alg.setkappa(kappa);
            
            for (int j = 0; j < n_gamma_ratio; j++){
                for (int s2 = 0; s2 < M; s2++){
                    gamma[s2] = gamma_ratio[j] * kappa[s2];

                }
                alg.setgamma(gamma);
                
                std::ostringstream kappa_str;
                std::ostringstream gamma_str;
                kappa_str << kappa_ratio[i];
                gamma_str << gamma_ratio[j];
                
                    
                    std::cout <<"\n\nrunning local search on " + initFile << " + ";// << c_file << " + ";
                    std::cout << mu_file << " + ";
                    std::cout <<M <<" clusters";
                    std::cout << " a : " << a;
                    std::cout << " kappa_ratio : " << kappa_ratio[i];
                    std::cout << " gamma_ratio : " << gamma_ratio[j];
                    
                    
                    
                    int* z = alg.localSearchPartition(initFile, a);
                    if (z == NULL) {
                        std::cout <<"\nNo partition is saved " ;
                        continue;
                    }
                   // std::cout <<"\nvertices cannot be put in any cluster: ";
                   // for (int ii = 0; ii < N; ii++){
                   //     if (z[ii] == -1)
                   //         std::cout <<ii << " ";
                   // }
                    
                    std::string z_file = output_folder + "z_" + fout_term + "_LS_N" + sN + "_M" + sM
                    + "_kappa" + kappa_str.str() + "_gamma" + gamma_str.str() + "_a" + a_str.str() + ".csv";
                    std::cout <<"\nSaving z into " << z_file << "\n";
                    tFile::saveIntFile(z, N, z_file, z_delimiter[0]);
                    
                    if (z != NULL) delete[] z;
                
                
                }//end of gamma
            }//end of kappa
    
    //std::cout <<"\ndeleting gamma";    
    
    if (gamma != NULL) delete[] gamma;
    
    //std::cout <<"\ndeleting kappa";    
    
    //std::cout << "\nkappa = " << kappa ;
    if (kappa != NULL) delete[] kappa;
	alg.setgamma(NULL);
	alg.setkappa(NULL);
}

void compute_cost(){
    std::cout <<"\nComputing GaussianCost() and EmpiricalCost";
   
    //loading time_varying weights
    
    std::vector<std::vector<double> > weightvec = tFile::readDoubleFileByRow(tv_weight_file, ',');
    
    if (N != weightvec.size()){
        std::cout << "\nN = " << N << "num of weight: " << weightvec.size();
        throw invalid_argument ("num of vertices and num of weight variables are not matched!");
    }
    
    int num_experiments = weightvec[0].size();
    
    //feeding weightvec into the X to call EmpiricalCost()
    
    double** X;

    X = new double* [N];
    for (int i = 0; i < N; i++){
        X[i] = new double [num_experiments];
        for (int j = 0; j < num_experiments; j++){
            X[i][j] = weightvec[i][j];
        }
    }
    
    double** K = new double* [M]; // for empiricalCOST
    for (int s = 0; s < M; s++)
        K[s] = new double [num_experiments];
        
   
    std::string z_metis_file = input_folder + z_metis_fname;
    std::string z_kmean_file = input_folder + z_kmean_fname;
    
    std::vector<int>  zvecMT = tFile::readIntFile1Column(z_metis_file);
    std::vector<int>  zvecKM = tFile::readIntFile1Column(z_kmean_file);
    
    
    std::string z_metisInit_file = output_folder + "z_metis_LS";
    std::string z_kmeanInit_file = output_folder + "z_kmean_LS";

    
    int num_alg = 4;
    
    std::string z_file[num_alg]; 
    
    z_file[0] = z_kmean_file;
    z_file[1] = z_metis_file;
    
    z_file[2] = z_kmeanInit_file;
    z_file[3] = z_metisInit_file;
    
            
    double* kappa = new double[M];
    double* gamma = new double[M];
    
    
    costs.setnum_experiments(num_experiments);
    costs.setX(X);
    
    //for (double d: geo_diameter_list){
       
        std::vector<std::vector<double> > costsaving;
        
        std::ostringstream streamD;

        for (int i = 0; i < n_kappa_ratio; i++){

            for (int s = 0; s < M; s++){
                kappa[s] = kappa_ratio[i] * sum_mu / (double) M;
            }
            
            costs.setkappa(kappa);
            
            std::ostringstream kappa_str;

            kappa_str << kappa_ratio[i];

            for (int j = 0; j < n_gamma_ratio; j++){

                for (int s = 0; s < M; s++){
                   gamma[s] = gamma_ratio[j] * kappa[s];

                }
                costs.setgamma(gamma);
                //generating normal distributions for K in EmpiricalCost()

                for (int s = 0; s < M; s++){
                    std::default_random_engine generator;
                    std::normal_distribution<double> distribution(kappa[i], gamma[j]);

                    for (int ii = 0; ii < num_experiments; ii++) {
                      K[s][ii] = distribution(generator);
                      if (K[s][ii] < 0) K[s][ii] = 0;
                      if (K[s][ii] > sum_mu) K[s][ii] = sum_mu;
                    }

                }
                costs.setK(K);
                std::ostringstream gamma_str;

                gamma_str << gamma_ratio[j];      
                
                
                for (double a : alist){
                    std::vector<double> costvec;
                    costvec.push_back(kappa_ratio[i]); costvec.push_back(gamma_ratio[j]);
                    costvec.push_back(a);
                    
                    std::ostringstream a_str;
                    a_str << a;
                    for (int al = 0; al < num_alg; al++){                                

                        std::vector<int> zvec;

                        if (al == 0){ //Kmean case

                            zvec = zvecKM;

                        }else if (al == 1) { //METIS
                            zvec = zvecMT;
                        }else
                        {                        
                            std::string local_z_file = z_file[al] +  "_N" +sN + "_M" + sM +
                                    "_kappa" + kappa_str.str() + "_gamma"  + gamma_str.str() + "_a" +a_str.str() +".csv";
                            zvec = tFile::readIntFile1Column(local_z_file); 
                            std::cout << "\nREADING " << local_z_file;

                         }
                        if (al < 2)
                            std::cout << "\nREADING " << z_file[al];

                        double GC = 0;
                        double EC = 0;
                        double sumcost = 0;
                        if (zvec.empty()){
                            GC = -sum_mu;
                            EC = -sum_mu;
                        }else{
                            int* z = new int [N];

                            int u = 0;
                            for (int s: zvec){
                                if (s > -1){
                                    z[u] = s; 
                                    u++;     
                                }else{
                                    GC = -sum_mu;
                                    EC = -sum_mu;
                                    break;
                                }
                            }
                            if (u == N){
                                costs.setz(z);
                                GC = costs.GaussianCost();
                                EC = costs.EmpiricalCost();
                                //sumcost = a * GC + (1-a)* costs.get_geoCost(zvec);
                                costs.setz(NULL);
                            }
                            if (z != NULL){ 
                               delete[] z;
                               z = NULL;
                            }

                        }
                        //costvec.push_back(sumcost/sum_mu);                    
                        costvec.push_back(EC/sum_mu);

                        zvec.erase(zvec.begin(), zvec.end());


                    } // of alg
                    //double lbc1 = costs.LowBoundCost1();
                    //double lbc2 = costs.LowBoundCost2();
                    //costvec.push_back(lbc1/sum_mu);
                    //costvec.push_back(lbc2/sum_mu);
                    costsaving.push_back(costvec);
                    //costvec.erase(costvec.begin(), costvec.end());
                }//of alist
            }// of gamma
            
        }//of kappa

        std::string cost_file = evaluation_folder + "EC_cost_M" + sM + +".csv";
        std::cout << "\nSaving cost file: " << cost_file;
        tFile::saveDoubleFile(costsaving, cost_file, ',');   
    //} //of diameter
    
    if (gamma != NULL) delete[] gamma;
    if (kappa != NULL) delete[] kappa;
    if (X != NULL){
        for (int i = 0; i < N; i++)
            delete[] X[i];
        delete[] X;
    }
    if (K != NULL){
        for (int i = 0; i < M; i++)
            delete[] K[i];
            delete[] K;
    }
	costs.setgamma(NULL);
	costs.setkappa(NULL);
	costs.setX(NULL);
	costs.setK(NULL);
}






int main(int argc, char** argv) {
    
    if (mkdir(output_folder.c_str(), 0777) == -1){
        //throw invalid_argument ("cannot create an output folder!");
    }
    if (mkdir(evaluation_folder.c_str(), 0777) == -1){
        //throw invalid_argument ("cannot create an evaluation folder!");
    }
    

    std::vector<std::vector<double> > mu_vec = tFile::readDoubleFileByRow(mu_file, mu_delimiter[0]);
    if (mu_vec.empty()){
            throw invalid_argument ("Cannot read mean weight file!");
    }

    //compute N
    
    N = mu_vec.size();

    
 //reading grid file,
    std::vector<std::vector<double> > grid_vec = tFile::readDoubleFileByRow(grid_file, grid_delimiter[0]);

    
    if (grid_vec.empty()){
        std::cout <<"\ngrid_file = " << grid_file;
            throw invalid_argument ("Cannot read grid file of graph!");
    }

    double** gridxy = new double*[N];
    int i = 0;
    
    for (std::vector<double> vec: grid_vec){
        gridxy[i] = new double[2];
        gridxy[i][0] = vec[0];
        gridxy[i][1] = vec[1];
        i++;
    };

    //feeding mu array
    
    double* mu = new double[N];
    double* mu_cost = new double[N];
    double* sigma = new double[N];
    double* sigma_cost = new double[N];
    
    i = 0;
    sum_mu = 0;
    
    for (std::vector<double> vec : mu_vec)
    {
        mu[i] = vec[0];
        mu_cost[i] = vec[0];
        sum_mu += mu[i];
        sigma[i] = vec[1];
        sigma_cost[i] = vec[1];
        i++;
        
    }
    
    
    alg.setN(N);
    alg.setM(M);
    alg.setiteration(n_iteration);
    
    alg.setmu(mu);
    alg.setsigma(sigma);
    alg.setgrid(gridxy);
  
    std::ostringstream streamN; streamN << N;           sN = streamN.str();
    std::ostringstream streamM; streamM << M;           sM = streamM.str();
    z_metis_fname = z_metis_fname + sM;
    z_kmean_fname = z_kmean_fname + sM;
    int n = 2;
    //std::string initFiles[] = {z_metis_fname};
    //std::string fout_terms[] = {"metis"};
    
    std::string initFiles[] = {z_kmean_fname, z_metis_fname};
    std::string fout_terms[] = {"kmean", "metis"};
    
    //run_RndPartition();
    //double a[] = {.1, .2, .3, .4, .5, .6, .7, .8};
    
    for (int i = 0; i < n; i++)
    for (int k = 0; k < num_a; k++)
    {
        
       run_localSearchPartition(input_folder + initFiles[i], fout_terms[i], alist[k]);
    }
    
    
    //alg.~algorithms();
    //compute costs:
    costs.setN(N);
    costs.setM(M);
    costs.setmu(mu_cost);
    costs.setsigma(sigma_cost);
    costs.setgrid(gridxy);
    //compute_cost();
    
    return 0;
}

