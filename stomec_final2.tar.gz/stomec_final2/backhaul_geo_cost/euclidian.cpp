/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   euclidian.cpp
 * Author: thuydt
 * 
 * Created on March 11, 2019, 11:54 AM
 * this is an interface to compute euclidian distance between 2 points
 */
#include <math.h>
#include "euclidian.h"


euclidian::euclidian() {
}

euclidian::euclidian(const euclidian& orig) {
}

euclidian::~euclidian() {
}

    
double euclidian::getDist(int p[], int q[], int n){
    double sum = 0;
    for (int i = 0; i < n; i++){
        sum += (double)((p[i] - q[i]) * (p[i] - q[i])); 
    }
    return sqrt(sum);
}
double euclidian::getDist(double p[], double q[], int n){
    double sum = 0;
    for (int i = 0; i < n; i++){
        sum += (p[i] - q[i]) * (p[i] - q[i]); 
    }
    return sqrt(sum);

}

double euclidian::getDist(int x1, int y1, int x2, int y2){
    return sqrt((double)((x1-x2) * (x1-x2) + (y1-y2) * (y1-y2)));
}
double euclidian::getDist(double x1, double y1, double x2, double y2){
    return sqrt((x1-x2) * (x1-x2) + (y1-y2) * (y1-y2));
}


