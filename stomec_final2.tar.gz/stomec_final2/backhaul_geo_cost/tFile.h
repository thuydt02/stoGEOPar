/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   tFile.h
 * Author: thuydt
 *
 * Created on January 27, 2019, 7:56 PM
 */

#ifndef TFILE_H
#define TFILE_H

#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
#include <string>
#include <sstream>

class tFile {
public:
    tFile();
    tFile(const tFile& orig);
    virtual ~tFile();
    
    //return a vector of vector of integer/double values
    //each row in file => each vector in returned object 
    static std::vector<std::vector<int> > readIntFileByRow(std::string fname, char delimiter);
    static std::vector<std::vector<double> > readDoubleFileByRow(std::string fname, char delimiter);
    
    //return a vector of vector of integer/double values
    //each column in file => each vector in returned object 
    
    static std::vector<std::vector<int> > readIntFileByColumn(std::string fname, char delimiter);
    static std::vector<std::vector<double> > readDoubleFileByColumn(std::string fname, char delimiter);
    
    static void saveIntFile(std::vector<std::vector<int> > data, std::string fname, char delimiter);
    static void saveIntFile(int* data, int N, std::string fname, char delimiter);
   
    static std::vector<double> readDoubleFile1Row(std::string fname, char delimiter);
    static std::vector<double> readDoubleFile1Column(std::string fname);
    
    static std::vector<int> readIntFile1Row(std::string fname, char delimiter);
    static std::vector<int> readIntFile1Column(std::string fname);
    
    static void saveDoubleFile(std::vector<std::vector<double> > data, std::string fname, char delimiter);
    static void saveDoubleFile(double* data, int N, std::string fname, char delimiter);
    
   
    
    
private:
    static std::vector<std::string> split(const std::string& s, char delimiter);

};

#endif /* TFILE_H */

