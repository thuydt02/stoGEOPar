/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   declares.h
 * Author: thuydt
 *
 * Created on January 24, 2019, 9:57 AM
 */
//#include <cstdlib>
//#include <stdio.h>
//#include <iostream>

//#include <complex>
//#include <valarray>
#include <vector>

//#include "x86_64-linux-gnu/c++/7/bits/stdc++.h" //nclab
//#include "/opt/local/include/gcc/c++/x86_64-apple-darwin17/bits/stdc++.h" //mac
//#include "bits/stdc++.h" //mac


//#include "/usr/include/c++/4.8.2/x86_64-redhat-linux/bits/stdc++.h"; //centos
//usr/include/c++/4.8.2/x86_64-redhat-linux/32/bits/stdc++.h



#ifndef DECLARES_H
#define DECLARES_H

const double PI = 3.141592653589793238460;
 
//typedef std::complex<double> Complex;
//typedef std::valarray<Complex> CArray;
//typedef std::valarray<int> IArray;
//typedef std::valarray<double> DArray;

typedef std::vector<int> ivector;


typedef struct pairVD{
    int ver, deg;
    pairVD(int v, int d){
        ver = v; deg = d;
    }
    pairVD(){};
}pairVD ;


#endif /* DECLARES_H */

