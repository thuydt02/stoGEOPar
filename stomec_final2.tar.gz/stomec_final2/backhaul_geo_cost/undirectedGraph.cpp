/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   undirectedGraph.cpp
 * Author: thuydt
 * 
 * Created on January 27, 2019, 11:19 AM
 */

#include <stdexcept>
#include <iostream>
#include "undirectedGraph.h"
#include "declares.h"

using namespace std;

undirectedGraph::undirectedGraph(int num_vertices, int** adj_mat) {
    if (num_vertices <= 0){
        throw std::invalid_argument ("Number of vertices cannot be <= 0!");
    }
    V = num_vertices;
    if (adj_mat == NULL){
        throw std::invalid_argument ("Adjacent matrix of the graph cannot be empty!");
    }
    c = adj_mat;
    d = NULL;
}
void undirectedGraph::setc(int** cmat){
    c = cmat;
};
undirectedGraph::undirectedGraph(const undirectedGraph& orig) {
}

undirectedGraph::~undirectedGraph() {
    //std::cout<< "\nudg 1";
    if (c != NULL) {
        for (int v = 0; v < V; v++){
            if (c[v] != NULL) delete[] c[v];
            //std::cout <<"\nudg2";
        }
        //std::cout <<"\nudg3";
        delete[] c;
    }
    //std::cout <<"\nudg4";
    if (d != NULL){
            for (int v = 0; v < V; v++){
                if (d[v] != NULL) delete[] d[v];
                //std::cout <<"\nudg5";
            }
        delete[] d;
        //std::cout <<"\nudg6";
    }
}

void undirectedGraph::computeDistanceMat(){
    d = new int*[V];
    for (int i = 0; i < V; i++){
        d[i] = dijkstra(i);
    }
        
    
}
int** undirectedGraph::getDistanceMat(){
    if (d == NULL) {
        computeDistanceMat();
    }
    return d;
}
std::vector<std::vector<int> > undirectedGraph::connectedComponents(int& ncom) 
{ 
    //ncom = how many components
    //return each component in a vector<int>
    
    // Mark all the vertices as not visited 
    bool *visited = new bool[V]; 
    for(int v = 0; v < V; v++) 
        visited[v] = false; 
    
    std::vector<std::vector<int> > retval;
    
    ncom = 0;
    for (int v= 0; v< V; v++) 
    { 
        if (visited[v] == false) 
        { 
            std::vector<int> tmp;
            DFSUtil(v, visited, tmp);
            retval.push_back(tmp);
            ncom++;
            tmp.erase(tmp.begin(), tmp.end());
        } 
    }
    
    if (visited != NULL) delete[] visited;
    return retval;
} 

int undirectedGraph::getConnectedComponents() 
{ 
    //return how many components
    // Mark all the vertices as not visited 
    
    bool *visited = new bool[V]; 
    for(int v = 0; v < V; v++) 
        visited[v] = false; 
    int ncom = 0;
    for (int v= 0; v< V; v++) 
    { 
        if (visited[v] == false) 
        { 
            std::vector<int> tmp;
            DFSUtil(v, visited, tmp);
            if (!tmp.empty())
                ncom++;
            tmp.erase(tmp.begin(), tmp.end());
        } 
    }
    if (visited != NULL) delete[] visited;
    return ncom;
} 
//check if a subgraph has diameter <= k

bool undirectedGraph::hasDiameterK(std::vector<int> subgraph, int k){
    if (subgraph.empty())
        return true;
    if (subgraph.size() == 1)
        return true;

    int n = subgraph.size();
    int mark[n][n];
    
    for (int i = 0; i < n ; i++)
        for (int j = 0; j < n ; j++)
            mark[i][j] = 0;

    int A[n][n], B[n][n], C[n][n];
    int u = 0, v = 0;
    for (int i: subgraph){
	v = 0;
        for (int j: subgraph){
            A[u][v] = c[i][j];
            B[u][v] = A[u][v];
            v++;
        }
        u++;
    }
    
    for (int d = 1; d <= k; d++){
        
        for (int i = 0; i < n; i++)
            for (int j = i ; j < n; j++){
                if (B[i][j] > 0) 
                    mark[i][j] = 1;
            }
        
        int count = 0;
        for (int i = 0; i < n ; i++)
            for (int j = i; j < n; j++)
                if (mark[i][j] == 0)
                    count++;
            
        if (count == 0){
            return true;
        }
        
        //B = B * A;
        for (int x = 0; x < n; x++){
            for (int y = 0; y < n; y++){
                C[x][y] = 0;
                for (int z = 0; z < n; z++){
                    C[x][y] += B[x][z]* A[z][y];
                }
            }
        }
        
        for (int x = 0; x < n; x++)
            for (int y = 0; y < n; y++)
                B[x][y] = C[x][y];
    }

    return false;
    
}
bool undirectedGraph::isConnected(){
    std::vector<int> list_v;
    for (int i = 0; i < V; i++)
        list_v.push_back(i);
    return isConnected(list_v);
}
    
bool undirectedGraph::isConnected(std::vector<int> subgraph){
    
//    int n = subgraph.size();
    
    if (subgraph.empty()){
        return true;
    }
    
    bool visited[V];
    for (int v = 0; v < V; v++)
        visited[v] = false;
    
        
    DFS_connected(*subgraph.begin(), subgraph, visited);    
    
    for (int v: subgraph)
        if (visited[v] == false) 
            return false;
    
    return true;
    
}

void undirectedGraph::DFS_connected(int v, std::vector<int> subgraph, bool visited[]){
    
    // Mark the current node as visited 
    visited[v] = true;    
    
    
    for (int u: subgraph){
        
        if (visited[u]) continue;
        
        if (undirectedGraph::c[v][u]  == 1){           
            undirectedGraph::DFS_connected(u, subgraph, visited);
        }
    }    
}


void undirectedGraph::DFSUtil(int v, bool visited[], std::vector<int> &retval) 
{ 
    // Mark the current node as visited 
    visited[v] = true; 
    retval.push_back(v);
   
    for (int u = 0; u < V; u++){
        if (c[v][u]  == 1){
            if (! visited[u])
                undirectedGraph::DFSUtil(u, visited, retval);
        }
    }
     
} 


int* undirectedGraph::dijkstra(int src) 
{ 
    
    // Function that implements Dijkstra's single source shortest path algorithm 
    // for a graph represented using adjacency matrix representation 

     int* dist = new int[V];     // The output array.  dist[i] will hold the shortest 
                      // distance from src to i 
   
     bool sptSet[V]; // sptSet[i] will be true if vertex i is included in shortest 
                     // path tree or shortest distance from src to i is finalized 
   
     // Initialize all distances as INFINITE and stpSet[] as false 
     for (int i = 0; i < V; i++) 
        dist[i] = INT_MAX, sptSet[i] = false; 
   
     // Distance of source vertex from itself is always 0 
     dist[src] = 0; 
   
     // Find shortest path for all vertices 
     for (int count = 0; count < V-1; count++) 
     { 
       // Pick the minimum distance vertex from the set of vertices not 
       // yet processed. u is always equal to src in the first iteration. 
       int u = minDistance(dist, sptSet); 
   
       // Mark the picked vertex as processed 
       sptSet[u] = true; 
   
       // Update dist value of the adjacent vertices of the picked vertex. 
       for (int v = 0; v < V; v++) 
   
         // Update dist[v] only if is not in sptSet, there is an edge from  
         // u to v, and total weight of path from src to  v through u is  
         // smaller than current value of dist[v] 
         if (!sptSet[v] && c[u][v] && dist[u] != INT_MAX  
                                       && dist[u]+c[u][v] < dist[v]) 
            dist[v] = dist[u] + c[u][v]; 
     } 
     return dist;
     // print the constructed distance array 
     //printSolution(dist, V); 
}

int** undirectedGraph::getsubAdj(std::vector<int> sg){
    int n = sg.size();
    int** sc = new int*[n];
    int i = 0; int j = 0;
    
    for (int u : sg){
        sc[i] = new int[n];
        j = 0;
        for (int v : sg){
            sc[i][j] = c[u][v];
            j++;
        }
        i++;
    }
    return sc;
}

int undirectedGraph::minDistance(int dist[], bool sptSet[]) 
{ 

    // A utility function to find the vertex with minimum distance value, from 
    // the set of vertices not yet included in shortest path tree 

    // Initialize min value 
   int min = INT_MAX, min_index; 
   
   for (int v = 0; v < V; v++) 
     if (sptSet[v] == false && dist[v] <= min) 
         min = dist[v], min_index = v; 
   
   return min_index; 
}

int undirectedGraph::getDiameter(){
    //if the graph is not CEONNECTED => return MAX_INT;
    int max = 0;
    int** dist = getDistanceMat();
    for (int i = 0; i < V; i++)
        for (int j = i; j < V; j++)
            if (max < dist[i][j]) max = dist[i][j];
    return max;
}

