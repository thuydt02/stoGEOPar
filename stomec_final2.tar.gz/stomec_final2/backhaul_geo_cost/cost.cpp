/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   cost.cpp
 * Author: thuydt
 * 
 * Created on February 19, 2019, 4:17 PM
 */
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <stdexcept>
#include <math.h>


#include "cost.h"
#include "algorithms.h"
//#include "declares.h"

using namespace std;
cost::cost() {
}

cost::cost(const cost& orig) {
}

cost::~cost() {
    /*if (z != NULL) delete[] z;
    if (mu != NULL) delete[] mu;
    if (sigma != NULL) delete[] sigma;
    if (gamma != NULL) delete[] gamma;
    if (kappa != NULL) delete[] kappa;
    if (X != NULL){ 
        for (int i = 0; i < N; i++)
            delete[] X[i];
            delete[] X;
    }
    if (K != NULL){
        for (int i = 0; i < N; i++)
            delete[] K[i];
        delete[] K;
    }
     */
}

double cost::LowBoundCost1(){
    double term1 = 0;
    double term2 = 0;
    double term3 = 0;
    
    for (int i = 0; i < N; i++){
        term1 += mu[i];
    }
    
    for (int s = 0; s < M; s++){
        term2 += kappa[s];
        term3 += gamma[s];
    }
    
    
    term1 = (term1 - term2) / (double) M;
    term3 = term3 / (double) M;
    //std::cout <<"\nLB1,term1,term2," << term1 << "," <<term3;
    return (double)M * algorithms::func(term1, term3);
} 

double cost::LowBoundCost2(){
   //more strict than LBCost1
    double term1 = 0;
    double term2 = 0;
    double term3 = 0;
    double term4 = 0;
    
    for (int i = 0; i < N; i++){
        term1 += mu[i];
        term2 += sigma[i] * sigma[i];
    }
    
    for (int s = 0; s < M; s++){
        term3 += kappa[s];
        term4 += gamma[s];
    }
    
    double mu_term = (term1 - term3)/(double)M;
    double sigma_term = sqrt(term2 + term4 * term4) / (double)M;
    //std::cout <<"\nLB2,term1,term2," << mu_term << "," <<sigma_term;
    return (double)M * algorithms::func(mu_term, sigma_term);
} 

double cost::GaussianCost(){
    
    //according to eq 76
   
    double omg = 0;
  
    for (int s = 0; s < M; s++){
        double term1 = 0;
        double term2 = 0;
        for (int i = 0; i < N; i++){
            if (z[i] == s){
                term1 += mu[i];
                term2 += sigma[i] * sigma[i];
            //    term1 += z[i][s] * mu[i];
            //    term2 += z[i][s] * sigma[i] * sigma[i];
            }
        }
        
        term1 = term1 - kappa[s];
        term2 = sqrt(term2 + gamma[s] * gamma[s]);        
        omg += algorithms::func(term1, term2);
    }
    
    return omg;
} 

double cost::EmpiricalCost(){
    //according to eq 6
    //in this case num_experiments = 192
   
    double x[N];
    double kappa[M]; 
    double sum = 0;
    for (int t = 0; t < num_experiments; t++){
        for (int i = 0; i < N; i++){
            x[i] = X[i][t];
        }
        for (int s = 0; s < M; s++){
            kappa[s] = K[s][t];
        }
        
        double max = 0;
        for (int s = 0; s < M; s++){
            double term = 0;
        
            for (int i = 0; i < N; i++){
                if (z[i] == s)
                    term += x[i];
                //term += z[i][s] * x[i];
            }
            if (term > kappa[s]){
                max += term-kappa[s];
            }
        }
        sum += max;
    }
    return sum / (double)num_experiments;
   
}


void cost::setN(int n_vertex){
    if (n_vertex < 1){
        throw invalid_argument("Num of vertices must be >= 1!");
    }
    N = n_vertex;
}
void cost::setM(int n_cluster){
    if (n_cluster < 1){
        throw invalid_argument("Num of clusters must be >= 1!");
    }
    M = n_cluster;
}
void cost::setnum_experiments(int n_experiment){
   if (n_experiment < 1){
        throw invalid_argument("Num of experiments must be >= 1!");
    }
   num_experiments = n_experiment; 
}
void cost::setz(int* z_arr){
    
    z = z_arr;
}
void cost::setmu(double* mean_weight){
    
    mu = mean_weight;
}
void cost::setsigma(double* var_weight){
    
    sigma = var_weight;

}
void cost::setkappa(double* mean_cap){
    
    kappa = mean_cap;
}
void cost::setgamma(double* var_cap){
    
    gamma = var_cap;
}
void cost::setX(double** varytimeweight){
    
    X = varytimeweight;

}
void cost::setK(double** varytimecap){
    
    K = varytimecap;
}

void cost::setgrid(double** gridxy){
    grid = gridxy;
}
    
/*
void cost::deletez(){
    if (z != NULL) delete z;
}
void cost::deletemu(){
    if (mu != NULL) delete mu;
}
void cost::deletesigma(){
    if (sigma != NULL) delete sigma;
}
void cost::deletekappa(){
    if (kappa != NULL) delete kappa;
}
void cost::deletegamma(){
    if (gamma != NULL) delete gamma;
}
void cost::deleteX(){
    if (X != NULL) delete X;
}
void cost::deleteK(){
    if (K != NULL) delete K;
}

*/

double cost::get_geoCost(std::vector<int> z){
    //return the geo_cost defined by kmean objective function
    
    ivector* V = new ivector [M];  //using vector because of dynamic size of each set V[i]
    int i = 0;
    for (int s: z){
        V[s].push_back(i); 
	i++;
    }
    double sum = 0; double t;
    for (int s = 0; s < M; s++){
        t = get_geoWCCost(V[s]);
        sum += t;
        //std::cout <<"\nget_geoCost(), s, cost = " << s << " , " << t;
      
    }
    //delete[] V;
    return sum;
    
}

double cost::get_geoWCCost(ivector Vs){
    //return geo_cost within cluster of Vs, see kmean objective function
    
    
    int n = Vs.size();
    double sum = 0;
    
    int p[n];
    int i = 0;
    for (int v: Vs){
        p[i] = v;
        i++;
    }
    
    double center[] = {0,0};
    
    double X = 0, Y = 0;
    for (int i = 0; i < n; i++){
        X += grid[p[i]][0];
        Y += grid[p[i]][1];        
    }
    center[0] = X / double(n);
    center[1] = Y / double(n);
    
    double dX, dY;
    for (int i = 0; i < n; i++){
       dX = (center[0] - grid[p[i]][0]);
       dY = (center[1] - grid[p[i]][1]);
       sum += dX * dX + dY * dY;
    }
    return sum;
    
}