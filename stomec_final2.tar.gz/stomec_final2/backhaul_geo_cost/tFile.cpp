/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   tFile.cpp
 * Author: thuydt
 * 
 * Created on January 27, 2019, 7:56 PM
 */

#include "tFile.h"

tFile::tFile() {
}

tFile::tFile(const tFile& orig) {
}

tFile::~tFile() {
}

std::vector<std::vector<int> > tFile::readIntFileByRow(std::string fname, char delimiter){
    std::ifstream myfile(fname);
 
    std::vector<std::vector<int> > retVal;

    std::string line = "";
    std::vector<std::string> svector;
    std::vector<int> ivector;
    while (getline(myfile, line))
    {
        
        svector = split(line, delimiter);
        for (std::vector<std::string>::iterator it = svector.begin(); it != svector.end(); it++){
            ivector.push_back(std::stoi(*it));
        }
        retVal.push_back(ivector);
        ivector.erase(ivector.begin(), ivector.end());
    }
    myfile.close();
    return retVal;
}


std::vector<std::vector<double> > tFile::readDoubleFileByRow(std::string fname, char delimiter){
    std::ifstream myfile(fname);
 
    std::vector<std::vector<double> > retVal;

    std::string line = "";
    std::vector<std::string> svector;
    std::vector<double> dvector;
    while (getline(myfile, line))
    {
        svector = split(line, delimiter);
        for (std::vector<std::string>::iterator it = svector.begin(); it != svector.end(); it++){
            dvector.push_back(std::stod(*it));
        }
        retVal.push_back(dvector);
        dvector.erase(dvector.begin(), dvector.end());
    }
    myfile.close();
    return retVal;
}
    
    //return a vector of vector of integer/double values
    //each column in file => each vector in returned object 
    
std::vector<std::vector<int> > tFile::readIntFileByColumn(std::string fname, char delimiter){
      std::ifstream myfile(fname);
 
    std::vector<std::vector<int> > retVal;

    std::string line = "";
    std::vector<std::string> svector;
    std::vector<int> ivector;
    int num_line = 0;
    int num_col = 0;
    while (getline(myfile, line))
    {
        if (!line.empty()) {
            num_line++;
            num_col = 0;
        }else
            continue;
        
        svector = split(line, delimiter);
        for (std::vector<std::string>::iterator it = svector.begin(); it != svector.end(); it++){
            ivector.push_back(std::stoi(*it));
            num_col++;
        }
        retVal.push_back(ivector);
        ivector.erase(ivector.begin(), ivector.end());
    }
    myfile.close();
    
    int tmp[num_line][num_col];
    
    int i = 0; int j = 0;
    for (std::vector<int> vec: retVal){
        j = 0;
        for (int ele: vec){
            tmp[i][j] = ele;
            j++;
        }
        i++;
    }
    
    retVal.erase(retVal.begin(), retVal.end());
    ivector.erase(ivector.begin(), ivector.end());
    
    
    for (int j = 0; j < num_col; j++){
        for (int i = 0; i < num_line; i++){
            ivector.push_back(tmp[i][j]);
        }

        retVal.push_back(ivector);
        ivector.erase(ivector.begin(), ivector.end());
    }

    return retVal;
  
}
std::vector<std::vector<double> > tFile::readDoubleFileByColumn(std::string fname, char delimiter){
    std::ifstream myfile(fname);
 
    std::vector<std::vector<double> > retVal;

    std::string line = "";
    std::vector<std::string> svector;
    std::vector<double> ivector;
    int num_line = 0;
    int num_col = 0;
    while (getline(myfile, line))
    {
        if (!line.empty()) {
            num_line++;
            num_col = 0;
        }else
            continue;
        
        svector = split(line, delimiter);
        for (std::vector<std::string>::iterator it = svector.begin(); it != svector.end(); it++){
            ivector.push_back(std::stoi(*it));
            num_col++;
        }
        retVal.push_back(ivector);
        ivector.erase(ivector.begin(), ivector.end());
    }
    myfile.close();
    
    double tmp[num_line][num_col];
    
    int i = 0; int j = 0;
    for (std::vector<double> vec: retVal){
        j = 0;
        for (double ele: vec){
            tmp[i][j] = ele;
            j++;
        }
        i++;
    }
    
    retVal.erase(retVal.begin(), retVal.end());
    ivector.erase(ivector.begin(), ivector.end());
    
    
    for (int j = 0; j < num_col; j++){
        for (int i = 0; i < num_line; i++){
            ivector.push_back(tmp[i][j]);
        }

        retVal.push_back(ivector);
        ivector.erase(ivector.begin(), ivector.end());
    }

    return retVal;
    
}

void tFile::saveIntFile(std::vector<std::vector<int> > data, std::string fname, char delimiter){
    
    //if (delimiter == '')
    //    delimiter = ' ';
    
    std::ofstream myfile(fname);
    
    if (myfile.is_open()){
        int num_ele = 0;
        bool checked = false;
        for (std::vector<int> vec: data){
            for (int ele: vec){
                num_ele++;
                
            }
            checked = true;
            if (checked) break;
        }
        int count;
        for (std::vector<int> vec: data){
            count = 0;
            for (int ele: vec){
                myfile << ele;
                count++;
                if (count < num_ele)
                    myfile << delimiter;
            }
            myfile << "\n";
        }

        
        myfile.close();
    }else
        std::cout <<"Cannot open the file to write!";
}
void tFile::saveDoubleFile(std::vector<std::vector<double> > data, std::string fname, char delimiter){
    //if (delimiter == '')
    //    delimiter = ' ';
    
    std::ofstream myfile(fname);
    
    if (myfile.is_open()){
        int num_ele = 0;
        bool checked = false;
        for (std::vector<double> vec: data){
            for (double ele: vec){
                num_ele++;
                
            }
            checked = true;
            if (checked) break;
        }
        
        int count;
        for (std::vector<double> vec: data){
            count = 0;
            for (double ele: vec){
                myfile << ele;
                count++;
                if (count < num_ele)
                    myfile << delimiter;
            }
            myfile << "\n";
        }
        myfile.close();
    }else
        std::cout <<"Cannot open the file to write!";
}

void tFile::saveIntFile(int* data, int N, std::string fname, char delimiter){
    
    std::ofstream myfile(fname);
    
    if (myfile.is_open()){
        for (int i = 0; i < N - 1; i++)
            myfile << data[i] << delimiter;
        
        myfile << data[N-1];
        myfile.close();
    }else
        std::cout <<"Cannot open the file to write!";
}

void tFile::saveDoubleFile(double* data, int N, std::string fname, char delimiter){
    std::ofstream myfile(fname);
    
    if (myfile.is_open()){
        for (int i = 0; i < N - 1; i++)
            myfile << data[i] << delimiter;
        
        myfile << data[N-1];
        myfile.close();
    }else
        std::cout <<"Cannot open the file to write!";

};
    



std::vector<double> tFile::readDoubleFile1Row(std::string fname, char delimiter){
    std::ifstream myfile(fname);
 
    std::string line = "";
    std::vector<std::string> svector;
    std::vector<double> dvector;
    
    while (getline(myfile, line))
    {
        svector = split(line, delimiter);
        for (std::vector<std::string>::iterator it = svector.begin(); it != svector.end(); it++){
            dvector.push_back(std::stod(*it));
        }
    }
    myfile.close();
    return dvector;

}
std::vector<double> tFile::readDoubleFile1Column(std::string fname){
    
    std::ifstream myfile(fname);

    

        std::string line = "";
        std::vector<double> dvector;

        while (getline(myfile, line))
        {

            dvector.push_back(std::stod(line));

        }
        myfile.close();
        return dvector;
    
    

    
}
    
std::vector<int> tFile::readIntFile1Row(std::string fname, char delimiter){
    std::ifstream myfile(fname);
 
    std::string line = "";
    std::vector<std::string> svector;
    std::vector<int> ivector;
    
    while (getline(myfile, line))
    {
        svector = split(line, delimiter);
        for (std::vector<std::string>::iterator it = svector.begin(); it != svector.end(); it++){
            ivector.push_back(std::stoi(*it));
        }
    }
    myfile.close();
    return ivector;

    
}
std::vector<int> tFile::readIntFile1Column(std::string fname){
    std::ifstream myfile(fname);
 
    std::string line = "";
    std::vector<int> ivector;
    
    while (getline(myfile, line))
    {
        
        ivector.push_back(std::stoi(line));
        
    }
    myfile.close();
    return ivector;

    
}
    

std::vector<std::string> tFile::split(const std::string& s, char delimiter)
{
   std::vector<std::string> tokens;
   std::string token;
   std::istringstream tokenStream(s);
   while (std::getline(tokenStream, token, delimiter))
   {
      tokens.push_back(token);
   }
   return tokens;
}

    

