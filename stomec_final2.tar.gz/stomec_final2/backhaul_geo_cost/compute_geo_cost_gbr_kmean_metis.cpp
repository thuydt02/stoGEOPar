#include <cstdlib>
#include <stdexcept>
#include <sys/stat.h>
#include <sys/types.h>
#include <iostream>
#include <sstream>
#include <cfloat>

#include "tFile.h"
#include "declares.h"

std::string base_folder = "../configuration11/"; //the graph is connected and has diameter of 56
std::string input_folder = base_folder + "input/";
std::string output_folder = base_folder + "output/";
std::string evaluation_folder = base_folder + "evaluation/";

int M = 100;

int n_kappa_ratio = 1;
double kappa_ratio[] = {1.5};

int n_gamma_ratio = 1;
double gamma_ratio[] = {.1};//, .3, .5, .7, .9};//gg

double alist[] = {0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1};
int num_a = 11;


std::string z_metis_fname = "mean_packets_AllBS_v2.graph.part.";

std::string z_kmean_fname = "z_kmean_K";

std::string grid_file = input_folder + "topology.xy";  //it is 2D coordinate points.
char* grid_delimiter = new char(',');

double** gridxy;

std::string sN;
std::string sM;

using namespace std;

double get_geoWCCost(ivector Vs){
    //return geo_cost within cluster of Vs, see kmean objective function
    
    
    int n = Vs.size();
    double sum = 0;
    
    int p[n];
    int i = 0;
    for (int v: Vs){
        p[i] = v;
        i++;
    }
    
    double center[] = {0,0};
    
    double X = 0, Y = 0;
    for (int i = 0; i < n; i++){
        X += gridxy[p[i]][0];
        Y += gridxy[p[i]][1];        
    }
    center[0] = X / double(n);
    center[1] = Y / double(n);
    
    double dX, dY;
    for (int i = 0; i < n; i++){
       dX = (center[0] - gridxy[p[i]][0]);
       dY = (center[1] - gridxy[p[i]][1]);
       sum += dX * dX + dY * dY;
    }
    return sum;
    
}
double get_geoCost(std::vector<int> z, int M){
    //return the geo_cost defined by kmean objective function
    
    
    
    ivector* V = new ivector [M];  //using vector because of dynamic size of each set V[i]
    int i = 0;
    for (int s: z){
        V[s].push_back(i); 
	i++;
    }
    double sum = 0; double t;
    for (int s = 0; s < M; s++){
        t = get_geoWCCost(V[s]);
        sum += t;
        //std::cout <<"\nget_geoCost(), s, cost = " << s << " , " << t;
      
    }
    //delete[] V;
    return sum;
    
}

int main(int argc, char** argv){
    
    std::vector<std::vector<double> > grid_vec = tFile::readDoubleFileByRow(grid_file, grid_delimiter[0]);

    
    if (grid_vec.empty()){
        std::cout <<"\ngrid_file = " << grid_file;
            throw invalid_argument ("Cannot read grid file of graph!");
    }

    //compute N
    
    int N = grid_vec.size();
    gridxy = new double*[N];
    int i = 0;
    
    for (std::vector<double> vec: grid_vec){
        gridxy[i] = new double[2];
        gridxy[i][0] = vec[0];
        gridxy[i][1] = vec[1];
        i++;
    };
    
    std::ostringstream streamM; streamM << M;           sM = streamM.str();
    std::ostringstream streamN; streamN << N;           sN = streamN.str();
    
    std::string z_random_file = output_folder + "z_RndPartition_N" + sN + "_M" + sM + ".csv";
    std::string z_metis_file = input_folder + z_metis_fname + sM;
    std::string z_kmean_file = input_folder + z_kmean_fname + sM;
    
    std::vector<int>  zvecRD = tFile::readIntFile1Column(z_random_file);
    std::vector<int>  zvecMT = tFile::readIntFile1Column(z_metis_file);
    std::vector<int>  zvecKM = tFile::readIntFile1Column(z_kmean_file);
    
    std::string z_metisInit_file = output_folder + "z_metis_LS";
    std::string z_kmeanInit_file = output_folder + "z_kmean_LS";

    
    std::cout <<"\n " << z_kmean_file;
    std::cout <<"\n " << z_metis_file;
    std::cout <<"\n " << z_random_file;
    //std::cout <<"\nzvecKM.size() " << zvecKM.size();
    
    double KM_geo_cost = get_geoCost(zvecKM, M);
    double MT_geo_cost = get_geoCost(zvecMT, M);
    double RD_geo_cost = get_geoCost(zvecRD, M);
    
    
    int num_alg = 4;
    
    std::string z_file[num_alg]; 
    
    z_file[0] = z_kmean_file;
    z_file[1] = z_metis_file;
    
    z_file[2] = z_kmeanInit_file;
    z_file[3] = z_metisInit_file;
    
    z_file[4] = z_random_file;
        
    
    std::vector<std::vector<double> > costsaving;
    
    
    for (double kap: kappa_ratio)
    {
        std::ostringstream kappa_str;

        kappa_str << kap;
            
        for (double gam: gamma_ratio){
        
                std::ostringstream gamma_str;

                gamma_str << gam;
                for (double a : alist){
                    std::ostringstream a_str;

                    a_str << a;
                    std::vector<double> costvec;
                    costvec.push_back(kap); costvec.push_back(gam);
                    costvec.push_back(a);
                    for (int al = 0; al < num_alg; al++){                                

                        std::vector<int> zvec;
                        double geocost = -1;
                        if (al == 0){ //Kmean case

                            geocost = KM_geo_cost;
                        //}else if (a == num_alg - 1){ //random case

                        //    geocost = RD_geo_cost;

                        }else if (al == 1) { //METIS
                            geocost = MT_geo_cost;
                        }

                        else
                        {                        
                            std::string local_z_file = z_file[al] +  "_N" +sN + "_M" + sM +
                                    "_kappa" + kappa_str.str() + "_gamma"  + gamma_str.str() + "_a"+ a_str.str()+  ".csv";
                            zvec = tFile::readIntFile1Column(local_z_file);                    
                            std::cout << "\nREADING " << local_z_file;
                        }
                        if (al < 2)
                        std::cout << "\nREADING " << z_file[al];

                        //if ((a < 2) || (a > 3))
                        //if ((al == 2) || (al == 3)) std::cout <<  "_N" +sN + "_M" + sM +
                        //            "_kappa" + kappa_str.str() + "_gamma"  + gamma_str.str() + ".csv";

                        if (!zvec.empty()){
                            geocost  = get_geoCost(zvec, M);
                        }
                        costvec.push_back(geocost);                    
                        zvec.erase(zvec.begin(), zvec.end());    
                    } // of alg
                    std::cout <<"\n";
                    costsaving.push_back(costvec);
                    //costvec.erase(costvec.begin(), costvec.end());
                }//of a
            }// of gamma
            
        }//of kappa

        std::string cost_file = evaluation_folder + "geo_cost_M" + sM + +".csv";
        std::cout << "\nSaving cost file: " << cost_file;
        tFile::saveDoubleFile(costsaving, cost_file, ',');
        
        for (int i = 0; i < N; i++){
            delete[] gridxy[i];
        }
        
        delete[] gridxy;
    return 0;
}
