#include <cstdlib>
#include <stdexcept>
#include <sys/stat.h>
#include <sys/types.h>
#include <iostream>
#include <sstream>


#include "tFile.h"
#include "undirectedGraph.h"
#include "declares.h"

std::string base_folder = "../configuration3/"; //the graph is connected and has diameter of 56
std::string input_folder = base_folder + "input/";

std::string output_folder = base_folder + "output/draft/"; //gg

std::string evaluation_folder = base_folder + "evaluation/";

std::string c_file = input_folder + "Graph_Adjacency_32.txt" ; // file name of adjacent matrix of a graph
char* c_delimiter = new char (' ');


std::string z_METIS_file = input_folder + "mean_packets_32.part32";
std::string z_file = output_folder + "z_GGPartition_D25_N752_M32_kappa0.4_gamma0.1.csv";


using namespace std;

int main(int argc, char** argv){


//reading METIS partition file => we can get M
    
    std::vector<int> vecMETIS = tFile::readIntFile1Column(z_file);// z_file
    
    //feeding zMETIS matrix to compute cost later
    
    if (vecMETIS.empty()){
        throw invalid_argument ("z_METIS file is empty or does not exist!!!");
    }
    int maxCluster = 0;
    
    for (int cc: vecMETIS){
        if (maxCluster < cc) maxCluster = cc;
    }

//getting clusters into V
    
    int M = maxCluster + 1;

    ivector* V = new ivector [M];  //using vector because of dynamic size of each set V[i]

    int i = 0;

    for (int s: vecMETIS){
        V[s].push_back(i); 
	i++;
    }
    
 //reading adjacent matrix,
    std::vector<std::vector<int> > adj_mat = tFile::readIntFileByRow(c_file, c_delimiter[0]);

    
    if (adj_mat.empty()){
            throw invalid_argument ("Cannot read adjacent matrix of graph!");
    }

    //compute N
    
    int N = adj_mat.size();

    //feeding c matrix
    int** c = new int*[N];
    i = 0; int j;
    for (std::vector<int> vec: adj_mat){
        c[i] = new int[N];
        j = 0;
        for (int ele: vec){
            c[i][j] = ele;
            j++;
        }
        i++;
    }

	undirectedGraph g(N,c);

    std::cout << "\nchecking diameter condition, diameter: ";
    for (int s = 0; s < M; s++){
	if (V[s].empty()) {
		std::cout <<"\nV[" <<s <<"]: size, diameter: 0";
        	continue;
	} 
              
	int** sc = g.getsubAdj(V[s]);
        undirectedGraph sg(V[s].size(), sc);
        std::cout <<"\nV[" <<s <<"]: size, diameter: " <<V[s].size() << ", " << sg.getDiameter();
        for (int i = 0; i < V[s].size(); i++){
            delete[] sc[i];
        }
        delete[] sc;
        sg.setc(NULL);
    }
    delete[] V;
    return 0;
}
