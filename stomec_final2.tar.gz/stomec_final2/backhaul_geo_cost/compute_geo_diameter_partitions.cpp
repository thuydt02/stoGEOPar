#include <cstdlib>
#include <stdexcept>
#include <sys/stat.h>
#include <sys/types.h>
#include <iostream>
#include <sstream>


#include "tFile.h"
#include "undirectedGraph.h"
#include "declares.h"
#include "euclidian.h"
#include "algorithms.h"

std::string base_folder = "../configuration3/"; //the graph is connected and has diameter of 56
std::string input_folder = base_folder + "output/geo_03_22/";

//std::string output_folder = base_folder + "output/draft/"; //gg

//std::string evaluation_folder = base_folder + "evaluation/";

//std::string c_file;// = input_folder + "Graph_Adjacency_32.txt" ; // file name of adjacent matrix of a graph
//char* c_delimiter = new char (' ');


//std::string z_METIS_file;// = input_folder + "mean_packets_32.part32";
//std::string z_file = output_folder + "z_GGPartition_D25_N752_M32_kappa0.4_gamma0.1.csv";

std::string grid_file = input_folder + "vertex_mapping_32.csv";
char* grid_delimiter = new char(',');

std::string kappa[] = {"1", "1.2", "1.4"};
std::string gamma[] = {"0.1", "0.3", "0.5", "0.7", "0.9"};
std::string sD[] = {"15"};

using namespace std;

int main(int argc, char** argv){


    //reading grid file,
    std::vector<std::vector<int> > grid_vec = tFile::readIntFileByRow(grid_file, grid_delimiter[0]);


    if (grid_vec.empty()){
        std::cout <<"\ngrid_file = " << grid_file;
            throw invalid_argument ("Cannot read grid file of graph!");
    }

    
//reading METIS partition file => we can get M

    for (std::string D: sD){
        
        std::string z_METIS_file = input_folder + "METIS_partitions/mean_packets_D" + D+ ".part.32";
        
        std::vector<int> vecMETIS = tFile::readIntFile1Column(z_METIS_file);// z_file

        //feeding zMETIS matrix to compute cost later

        if (vecMETIS.empty()){
            throw invalid_argument ("z_METIS file is empty or does not exist!!!");
        }
        int maxCluster = 0;

        for (int cc: vecMETIS){
            if (maxCluster < cc) maxCluster = cc;
        }

    //getting clusters into V

        int M = maxCluster + 1;

        ivector* V = new ivector [M];  //using vector because of dynamic size of each set V[i]

        int i = 0;

        for (int s: vecMETIS){
            V[s].push_back(i); 
            i++;
        }

     
        //compute N

        int N = grid_vec.size();
        int** gridxy = new int*[N];

        i = 0;

        for (std::vector<int> vec: grid_vec){
            gridxy[i] = new int[2];
            gridxy[i][0] = vec[0];
            gridxy[i][1] = vec[1];
            i++;
        };
        algorithms alg;
        alg.setN(N);
        alg.setM(M);
        alg.setgrid(gridxy);
        
        alg.setc(NULL);
        alg.setgamma(NULL);
        alg.setkappa(NULL);
        alg.setmu(NULL);
        alg.setsigma(NULL);
        
        //std::cout << "\nchecking geo-diameter condition on " + z_METIS_file;
        double max = 0;
        for (int s = 0; s < M; s++){
            double geo = alg.getgeo_diameter(V[s]);
            if (max < geo) max = geo;
            //std::cout <<"\nV[" <<s <<"]: size, geo-diameter: " <<V[s].size() << ", " << geo;

        }
        std::cout <<"\n" <<z_METIS_file << ", max_geo_diameter: " <<max <<"\n";
        //for (i = 0; i < N; i++){
        //    delete[] gridxy[i];
        //}
        //delete[] gridxy; gridxy = NULL;
        delete[] V;
    }
    
    return 0;
}
