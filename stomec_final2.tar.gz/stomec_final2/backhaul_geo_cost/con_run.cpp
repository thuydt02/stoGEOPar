//
//  run_all.cpp
//  
//
//  Created by Thuy Do on 2/17/19.
//
//
//This code is to run all alg :KG, GG, GBR (3 options of initializeF)
//and compute costs

#include <cstdlib>
#include <stdexcept>
#include <sys/stat.h>
#include <sys/types.h>
#include <iostream>
#include <sstream>
#include <random>

#include "algorithms.h"
#include "tFile.h"
#include "cost.h"

using namespace std;

//configuration, see algorithms for meanings
int N;
int M = 100;
int n_iteration = 4000;
//double geo_diameter_list[] = {3}; // here 1 unit = 1.23 km realistically 

std::string base_folder = "../configuration11/";
std::string input_folder = base_folder + "input/";

std::string output_folder = base_folder + "output/"; 
std::string evaluation_folder = base_folder + "evaluation/";
std::string convergence_folder = base_folder + "convergence/";

char* mu_delimiter = new char(',');
std::string mu_file = input_folder + "TimeVaryingWeights_packets_AllBS.MeanSD";

char* z_delimiter = new char('\n');

std::string tv_weight_file = input_folder + "TimeVaryingWeights_packets_AllBS.csv";

std::string grid_file = input_folder + "topology.xy";  //it is 2D coordinate points.
char* grid_delimiter = new char(',');

std::string z_metis_fname = "mean_packets_AllBS_v2.graph.part.";
std::string z_kmean_fname = "z_kmean_K";
std::string z_rd_fname = "z_RndPartition";
        
int n_kappa_ratio = 3;
double kappa_ratio[] = {1, 1.3, 1.5};

int n_gamma_ratio = 5;
double gamma_ratio[] = {.1, .3, .5, .7, .9};
double alist[] = {.5};// {0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1};
int num_a = 1;//1;

double sum_mu;

algorithms alg; // to run all algs


//for ease

std::string sN;
std::string sM;


void run_localSearchPartition(std::string initFile, std::string fout_term){
    
    
    std::vector<std::vector<double>> consaving;
    
    double* kappa = new double[M];            
    //std::cout << "kappa = " << kappa ;
    
    double* gamma = new double[M];        
        
        
        for (int i = 0; i < n_kappa_ratio; i++){

            for (int s1 = 0; s1 < M; s1++){
                kappa[s1] = kappa_ratio[i] * sum_mu / (double) M;

            }
            alg.setkappa(kappa);
            
            for (int j = 0; j < n_gamma_ratio; j++){
                for (int s2 = 0; s2 < M; s2++){
                    gamma[s2] = gamma_ratio[j] * kappa[s2];

                }
                alg.setgamma(gamma);
                
                std::ostringstream kappa_str;
                std::ostringstream gamma_str;
                kappa_str << kappa_ratio[i];
                gamma_str << gamma_ratio[j];
    
                
                    
                for (double a : alist){
                    std::ostringstream a_str;
                    a_str << a;
                    
                    std::cout <<"\n\nrunning local search on " + initFile << " + ";// << c_file << " + ";
                    std::cout << mu_file << " + ";
                    std::cout <<M <<" clusters";
                    std::cout << " a : " << a;
                    std::cout << " kappa_ratio : " << kappa_ratio[i];
                    std::cout << " gamma_ratio : " << gamma_ratio[j];
                    
                    int z = alg.con_localSearchPartition(initFile, a);
                    
                    std::vector<double> convec;
                    convec.push_back(kappa_ratio[i]);
                    convec.push_back(gamma_ratio[j]);
                    convec.push_back(a);
                    convec.push_back(z);
                    
                    consaving.push_back(convec);
                }//end of a
            }//end of gamma
        }//end of kappa
    
    std::string con_file = convergence_folder + "con_M" + sM + +".csv";
    std::cout << "\nSaving con file: " << con_file;
    tFile::saveDoubleFile(consaving, con_file, ',');

    if (gamma != NULL) delete[] gamma;
    
    //std::cout <<"\ndeleting kappa";    
    
    //std::cout << "\nkappa = " << kappa ;
    if (kappa != NULL) delete[] kappa;
	alg.setgamma(NULL);
	alg.setkappa(NULL);
}


int main(int argc, char** argv) {
    
    if (mkdir(output_folder.c_str(), 0777) == -1){
        //throw invalid_argument ("cannot create an output folder!");
    }
    if (mkdir(evaluation_folder.c_str(), 0777) == -1){
        //throw invalid_argument ("cannot create an evaluation folder!");
    }
    

    std::vector<std::vector<double> > mu_vec = tFile::readDoubleFileByRow(mu_file, mu_delimiter[0]);
    if (mu_vec.empty()){
            throw invalid_argument ("Cannot read mean weight file!");
    }

    //compute N
    
    N = mu_vec.size();

    
 //reading grid file,
    std::vector<std::vector<double> > grid_vec = tFile::readDoubleFileByRow(grid_file, grid_delimiter[0]);

    
    if (grid_vec.empty()){
        std::cout <<"\ngrid_file = " << grid_file;
            throw invalid_argument ("Cannot read grid file of graph!");
    }

    double** gridxy = new double*[N];
    int i = 0;
    
    for (std::vector<double> vec: grid_vec){
        gridxy[i] = new double[2];
        gridxy[i][0] = vec[0];
        gridxy[i][1] = vec[1];
        i++;
    };

    //feeding mu array
    
    double* mu = new double[N];
    double* mu_cost = new double[N];
    double* sigma = new double[N];
    double* sigma_cost = new double[N];
    
    i = 0;
    sum_mu = 0;
    
    for (std::vector<double> vec : mu_vec)
    {
        mu[i] = vec[0];
        mu_cost[i] = vec[0];
        sum_mu += mu[i];
        sigma[i] = vec[1];
        sigma_cost[i] = vec[1];
        i++;
        
    }
    
    
    alg.setN(N);
    alg.setM(M);
    alg.setiteration(n_iteration);
    
    alg.setmu(mu);
    alg.setsigma(sigma);
    alg.setgrid(gridxy);
  
    std::ostringstream streamN; streamN << N;           sN = streamN.str();
    std::ostringstream streamM; streamM << M;           sM = streamM.str();
    z_metis_fname = z_metis_fname + sM;
    z_kmean_fname = z_kmean_fname + sM;
    int n = 1;
    //std::string initFiles[] = {z_metis_fname};
    //std::string fout_terms[] = {"metis"};
    z_rd_fname = z_rd_fname + "_N" + sN + "_M" + sM + ".csv";
    std::string initFiles[] = {z_rd_fname};//{z_kmean_fname, z_metis_fname};
    std::string fout_terms[] = {"rd"};
    
    //run_RndPartition();
    //double a[] = {.1, .2, .3, .4, .5, .6, .7, .8};
    
    for (int i = 0; i < n; i++)
    //for (int k = 0; k < num_a; k++)
    {
        
      run_localSearchPartition(output_folder + initFiles[i], fout_terms[i]);//, alist[k]);
    }
    
    
    //alg.~algorithms();
    //compute costs:

    
    return 0;
}

