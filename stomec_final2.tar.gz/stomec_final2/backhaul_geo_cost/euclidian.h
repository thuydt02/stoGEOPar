/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   euclidian.h
 * Author: thuydt
 *
 * Created on March 11, 2019, 11:54 AM
 * this is an interface to compute euclidian distance between 2 points
 */

#ifndef EUCLIDIAN_H
#define EUCLIDIAN_H

class euclidian {
public:
    euclidian();
    euclidian(const euclidian& orig);
    virtual ~euclidian();
    
    static double getDist(int p[], int q[], int n);
    static double getDist(double p[], double q[], int n);
   
    static double getDist(int x1, int y1, int x2, int y2);
    static double getDist(double x1, double y1, double x2, double y2);
    
private:

};

#endif /* EUCLIDIAN_H */

