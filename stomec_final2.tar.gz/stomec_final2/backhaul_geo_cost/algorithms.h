/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   algorithms.h
 * Author: thuydt
 *
 * Created on January 24, 2019, 9:56 AM
 */
#include "declares.h"
#include <math.h>
#ifndef ALGORITHMS_H
#define ALGORITHMS_H


class algorithms {
public:
    algorithms(int num_iter, int n_vertex, int n_cluster, double* mean_weight, double* var_weight, double* mean_cap, double* var_cap);
    algorithms(const algorithms& orig);
    algorithms();;
    virtual ~algorithms();
    
    int* RandomPartition();
    
    //-------------------------------------------	
    static double func(double mu, double sigma);
    
    void setN(int num_vertex);
    void setM(int num_cluster);
    void setiteration(int num_iter);
    
    void setmu(double* mean_weight);
    void setsigma(double* var_weight);
    void setkappa(double* mean_cap);
    void setgamma(double* var_cap);
    
    
    void setgrid(double** gridxy);
    double getgeo_diameter(std::vector<int> Vs); //return geo-diameter of a cluster 
    
    double getgeo_diameter_if_addnew(std::vector<int> Vs, int vertex, double old_diameter );
    double getGC(ivector* V);
    double* getCentroid(std::vector<int> Vs);
    
    void swap(int k, int* vertices, int* S, int* U, ivector* V);
    
    int shifting(ivector* V, double a);
    int* localSearchPartition(std::string initFile, double a);
    
    //for convergence seeing
    
    int con_localSearchPartition(std::string initFile, double a);
    
    
private:
    
    int n_iteration;
    int N, M; // num of vertices and num of clusters, index from 0
    
    double* mu; //mean of weight of graph vertices
    double* sigma; //variance of weight of graph vertices
    double* kappa; //mean of capacities of clusters
    double* gamma; //variance of capacities of cluters
    
    double** grid; //(gridX, gridY) pair of each vertex.
    //double geo_diameter; //threshold of geo_diameter of all clusters.
                         //each cluster has geo-diameter < geo_diameter
                         //geo_diameter(a cluster) = max {euclidian distances between any 2 vertices }
    
    
    
    double sum_mu;
    double kmean_cost_1cluster;
    
    //double* cX; // centers of clusters
    //double* cY; 
    //double* cur_diameter;// current diameters of clusters
    //int** A;// M x M matrix, A[i,j] = 1 means cluster i and cluster j are neighbors 
    //------------------------------------------------------------
    //for algorithm 1
    //------------------------------------------------------------
    //given a vertex v in the graph c, and the subgraph Vs, 
    //check if we include v in Vs and new Vs still connected 
    //bool connected(int v, ivector Vs);
    //------------------------------------------------------------
    //given a vertex v, in the graph c, check if we can include v in a cluster s
    //s in [0, M-1]
    //conditions: V[s] still connected if v added, not excess kappa[s], max of kappa[s] - mu[s]
    //return s if found, otherwise return M
    int find_s_given_ver(int v, ivector* V, double* u, double* cur_diameter);
    //------------------------------------------------------------
    //-------------------------------------------------------------
    //for calling sort()
    static bool comparator(pairVD p1, pairVD p2);
    //-------------------------------------------------------------
    //for algorithm 2
    //------------------------------------------------------------
    //find pair of i and s in algorithm 2
    int* find_pair_is(std::vector<int> not_in_cluster, ivector* V, double* u, double* v, double* f, double* cur_diameter);
    static double lower_phi(double x);
    static double upper_phi(double x);
    
    //------------------------------------------------------------
    //for alg3
    //------------------------------------------------------------
    ivector* initializeFByFile(std::string initFile);
    double get_geoWCCost(ivector Vs);
    double get_geoWCCcost_IfRemovePoint(ivector Vs, int u);
    double get_geoWCCost_IfAddPoint(ivector Vs, int u);
    double get_geoCost(ivector* V);
    double get_allCost(ivector* V);
};


#endif /* ALGORITHMS_H */

