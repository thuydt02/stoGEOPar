#include <cstdlib>
#include <stdexcept>
#include <sys/stat.h>
#include <sys/types.h>
#include <iostream>
#include <sstream>
#include <cfloat>

#include "tFile.h"
#include "declares.h"
#include "euclidian.h"
#include "algorithms.h"

std::string base_folder = "../configuration11/"; //the graph is connected and has diameter of 56
std::string input_folder = base_folder + "input/";


//std::string z_file = input_folder + "mean_packets_AllBS.graph.part.25";

std::string z_file = input_folder + "z_kmean_K100";

std::string grid_file = input_folder + "topology.xy";  //it is 2D coordinate points.
char* grid_delimiter = new char(',');

using namespace std;

int main(int argc, char** argv){


//reading METIS partition file => we can get M
    
    std::vector<int> vec = tFile::readIntFile1Column(z_file);// z_file
    
    //feeding zMETIS matrix to compute cost later
    
    if (vec.empty()){
        throw invalid_argument ("\n" + z_file + " is empty or does not exist!!!");
    }
    int maxCluster = 0;
    
    for (int cc: vec){
        if (maxCluster < cc) maxCluster = cc;
    }

//getting clusters into V
    
    int M = maxCluster + 1;
    std::cout <<"\nM = " <<M;
    ivector* V = new ivector [M];  //using vector because of dynamic size of each set V[i]

    int i = 0;

    for (int s: vec){
        V[s].push_back(i); 
	i++;
    }
    
 //reading grid file,
    std::vector<std::vector<int> > grid_vec = tFile::readIntFileByRow(grid_file, grid_delimiter[0]);

    
    if (grid_vec.empty()){
        std::cout <<"\ngrid_file = " << grid_file;
            throw invalid_argument ("Cannot read grid file of graph!");
    }

    //compute N
    
    int N = grid_vec.size();
    int** gridxy = new int*[N];
    i = 0;
    
    for (std::vector<int> vec: grid_vec){
        gridxy[i] = new int[2];
        gridxy[i][0] = vec[0];
        gridxy[i][1] = vec[1];
        i++;
    };
    algorithms alg;
    alg.setN(N);
    alg.setM(M);
    alg.setgrid(gridxy);
    std::cout << "\nchecking geo-diameter condition on " + z_file;
    double avg_dia = 0; double max_dia = 0; double min_dia = DBL_MAX;
    for (int s = 0; s < M; s++){
        double tmp = alg.getgeo_diameter(V[s]);
        if (tmp > max_dia)
            max_dia = tmp;
        if (tmp < min_dia)
            min_dia = tmp;
        
        avg_dia += tmp;
	std::cout <<"\nV[" <<s <<"]: size, geo-diameter: " <<V[s].size() << ", " << tmp;
        
    }
    avg_dia = avg_dia / M;
    
    std::cout <<"\n max diameter, min diameter, avg diameter: "<<max_dia << ", " <<min_dia <<", " << avg_dia;
    delete[] V;
    return 0;
}
