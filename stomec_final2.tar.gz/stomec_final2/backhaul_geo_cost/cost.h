/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   cost.h
 * Author: thuydt
 *
 * Created on February 19, 2019, 4:17 PM
 */
//to compute the cost of StoMEC
#ifndef COST_H
#define COST_H
#include <iostream>
#include "declares.h"


class cost {
public:
    cost();
    cost(const cost& orig);
    virtual ~cost();
    double GaussianCost();
    double EmpiricalCost();
    double LowBoundCost1();
    double LowBoundCost2();
    void setN(int n_vertex);
    void setM(int n_cluster);
    void setnum_experiments(int n_experiment);
    void setz(int* z_arr);
    void setmu(double* mean_weight);
    void setsigma(double* var_weight);
    void setkappa(double* mean_cap);
    void setgamma(double* var_cap);
    void setX(double** varytimeweight);
    void setK(double** varytimecap);
    void setgrid(double** gridxy);
    double get_geoCost(std::vector<int> z);
    double get_geoWCCost(ivector Vs);

    
private:
    int N;
    int M;
    int num_experiments;
    
    int* z; //
    double* mu;
    double* sigma;
    double* kappa;
    double* gamma;
    double** X; //varying time weights to compute Empirical Cost
    double** K; //varying time capacities to compute EC 
    
    double** grid;
};

#endif /* COST_H */

