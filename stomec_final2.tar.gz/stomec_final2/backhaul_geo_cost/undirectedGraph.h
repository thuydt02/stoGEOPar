/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   undirectedGraph.h
 * Author: thuydt
 *
 * Created on January 27, 2019, 11:19 AM
 */

#ifndef UNDIRECTEDGRAPH_H
#define UNDIRECTEDGRAPH_H

#include <vector>

class undirectedGraph {
public:
    undirectedGraph(int num_vertices, int** adj_mat);
    undirectedGraph(const undirectedGraph& orig);
    void setc(int** cmat);
    virtual ~undirectedGraph();
    
    std::vector<std::vector<int> > connectedComponents(int& ncom);
    int getConnectedComponents();
    
    //given a subgraph, check if it is connected
    bool isConnected(std::vector<int> subgraph);
    bool isConnected();
    //return true if subgraph has diameter <= k
    bool hasDiameterK(std::vector<int> subgraph, int k);
    void computeDistanceMat();
    int** getDistanceMat();
    int* dijkstra(int src);
    int getDiameter();
    //return a sub adjacent matrix of subgraph sg 
    int** getsubAdj(std::vector<int> sg);
private:
    int V; //number of vertices
    int** c; //adjacent matrix
    int** d; //distance matrix
    
        // A function used by DFS 
    void DFSUtil(int v, bool visited[], std::vector<int> &retval); 
    void DFS_connected(int v, std::vector<int> subgraph, bool visited[]);
    
    int minDistance(int dist[], bool sptSet[]);
};

#endif /* UNDIRECTEDGRAPH_H */
