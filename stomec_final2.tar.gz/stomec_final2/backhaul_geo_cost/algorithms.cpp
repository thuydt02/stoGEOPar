/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   algorithms.cpp
 * Author: thuydt
 *
 * Created on January 24, 2019, 9:56 AM
 */
#include <algorithm>
#include <cfloat> 

#include "algorithms.h"
#include "tFile.h"
#include "euclidian.h"



using namespace std;

void algorithms::setN(int num_vertex){
    if (num_vertex < 1){
        throw invalid_argument("Graph must have >= 1 vertices!");
    }
    N = num_vertex;
}
void algorithms::setM(int num_cluster){
    if (num_cluster < 1){
        throw invalid_argument("num of clusters must be >= 1!");
    }
    M = num_cluster;
}
void algorithms::setiteration(int num_iter){
    if (num_iter < 1){
        throw invalid_argument("num of iteration must be >= 1!");
    }
    n_iteration = num_iter;
}

void algorithms::setmu(double* mean_weight){
    
    mu = mean_weight;
    sum_mu = 0;
    if (mean_weight != NULL){
        for (int i = 0; i < N; i++){
            sum_mu += mu[i];
        }
    }
}
void algorithms::setsigma(double* var_weight){
    
    sigma = var_weight;
}
void algorithms::setkappa(double* mean_cap){
    
    kappa = mean_cap;
}
void algorithms::setgamma(double* var_cap){
    
    gamma = var_cap;
}
void algorithms::setgrid(double** gridxy){
    
    grid = gridxy;
    kmean_cost_1cluster = 0;
    
    if (gridxy != NULL){
        
        double center[] = {0,0};

        double X = 0, Y = 0;
        for (int i = 0; i < N; i++){
            X += grid[i][0];
            Y += grid[i][1];        
        }
        center[0] = X / double(N);
        center[1] = Y / double(N);

        double dX, dY;
        
        for (int i = 0; i < N; i++){
           dX = (center[0] - grid[i][0]);
           dY = (center[1] - grid[i][1]);
           kmean_cost_1cluster += dX * dX + dY * dY;
        }
    }
}
    
algorithms::algorithms(int num_iter, int n_vertex, int n_cluster, double* mean_weight, double* var_weight, double* mean_cap, double* var_cap){
    if (num_iter <= 0){
        throw invalid_argument("num of iteration must be >= 1!");
    }
    n_iteration = num_iter;
    
    if (n_vertex < 1){
        throw invalid_argument("Graph must have >= 1 vertices!");
    }
    N = n_vertex;
    
    if (n_cluster < 1){
        throw invalid_argument("num of clusters must be >= 1!");
    }
    M = n_cluster;
    
    
    if (mean_weight == NULL){
        throw invalid_argument ("mean of weights is EMPTY!");
    }
    mu = mean_weight;
    
    if (var_weight == NULL){
        throw invalid_argument ("variance of weights is EMPTY!");
    }
    sigma = var_weight;
    
    if (mean_cap == NULL){
        throw invalid_argument ("mean of capacities is EMPTY!");
    }
    kappa = mean_cap;
    
    if (var_cap == NULL){
        throw invalid_argument ("variance of capacities is EMPTY!");
    }
    gamma = var_cap;
}
algorithms::algorithms(){};
algorithms::algorithms(const algorithms& orig) {
}

algorithms::~algorithms() {

    if (grid != NULL) {
        for (int i = 0; i < N; i++){
            delete[] grid[i];
        }
        delete[] grid;
    }
//    if (cX != NULL) delete[] cX;
//    if (cY != NULL) delete[] cY;
//    if (cur_diameter != NULL) delete[] cur_diameter;
//    if (A!= NULL){
//        for (int s = 0; s < M; s++)
//            delete[] A[s];
//            delete[] A;
    //}
    if (mu != NULL) delete[] mu;
    
    if (sigma != NULL) delete[] sigma;
    
    if (kappa != NULL) delete[] kappa;
    if (gamma != NULL) delete[] gamma;
    
   grid = NULL; //cX = NULL; cY = NULL; cur_diameter = NULL; A = NULL;
   mu = NULL; sigma = NULL; kappa = NULL; gamma = NULL;
}


int* algorithms::RandomPartition(){
    
    ivector* V =  new ivector[M];
    int inCluster[N];
    for (int i = 0; i < N; i++)
        inCluster[i] = 0;
    
    srand(time(NULL));
    int count = 0;
    
    while (true){
        
        int s = rand() % M;
        int i = rand() % N;
        
        if (inCluster[i] == 1)
            continue;
        
        inCluster[i] = 1;
        V[s].push_back(i);
        count++;
        if (count == N) break;
    }
    
    int* z = new int [N];
	for (int i = 0; i < N; i++) z[i] = -1;
	    
	for (int s = 0; s < M; s++){
            for (int i: V[s]){
                z[i] = s;
            }
        }
    delete[] V;
    return z;
}



double algorithms::func(double mu, double sigma){
    if (sigma == 0) {
        throw std::invalid_argument ("Sigma cannot be zero!");
        return -1;
    }
    
    return sigma * lower_phi(-mu/sigma) + mu * (1 - upper_phi(-mu/sigma));
};

double algorithms::lower_phi(double x){
    //pdf
    double term = 1.0 / sqrt(2.0 * PI);
    return term * exp(-0.5 * x * x);
};

double algorithms::upper_phi(double x){
    //cdf(x)
    return 1.0/2.0 * (1.0 + erf(x/sqrt(2.0)));
}


ivector* algorithms::initializeFByFile(std::string initFile){
    
    std::vector<int> z = tFile::readIntFile1Column(initFile);
    if (z.empty()){
        std::cout <<"\ninitFile = " << initFile;
        throw invalid_argument ("The initial partition file is empty or does not exist!");
    }
    
    ivector* V = new ivector [M];  //using vector because of dynamic size of each set V[i]
    int i = 0;
    for (int s: z){
        if ((s < 0) || (s >= M)) return NULL;
        V[s].push_back(i);
        i++;
    }
    
    return V;
} 


//for all algs
  
double algorithms::getgeo_diameter(std::vector<int> Vs){ //return geo-diameter of Vs 
    if (Vs.empty()) return 0;
    if (Vs.size() == 1) return 0;
    
    int n = Vs.size();
    
    int p[n];
    int i = 0;
    for (int v: Vs){
        p[i] = v;
        i++;
    }
    double max = 0; double tmp;
    
    for (int i = 0; i < n-1; i++){
        for (int j = i + 1; j < n; j++){
            tmp = euclidian::getDist(grid[p[i]][0], grid[p[i]][1], grid[p[j]][0], grid[p[j]][1]);
            if (max < tmp) max = tmp;       
        }
    }
    //std::cout <<"\nVs.size() = " <<Vs.size();
    return max;
    
}

double algorithms::getgeo_diameter_if_addnew(std::vector<int> Vs, int vertex, double old_diameter ){
    //return the diameter of the cluster if adding new_vertex,
    //old_diameter is the current diameter of Vs
    
    if (Vs.empty()) return 0;
    
    int n = Vs.size();
    
    int p[n];
    int i = 0;
    for (int v: Vs){
        p[i] = v;
        i++;
    }
    
    double max = old_diameter; double tmp;
    for (int i = 0; i < n; i++){
        
        tmp = euclidian::getDist(grid[p[i]][0], grid[p[i]][1], grid[vertex][0], grid[vertex][1]);
            if (max < tmp) max = tmp;       
    }
    
    return max;
}

//-------------------------------------------------------------------
int* algorithms::localSearchPartition(std::string initFile, double a){
    //given a partition in initFile
    //return a refined partition in terms of Gaussian Cost
    
    ivector* V = NULL;
    std::cout <<"\nin LS: initFile = " <<initFile;
        
    if (initFile.empty()){
        std::cout <<"\ninitFile = " <<initFile <<" is EMPTY!";
        return NULL;
    }else{
        
        V = initializeFByFile(initFile);
        
        if (V == NULL){
            std::cout <<"\ninitFile = " <<initFile;
            std::cout <<"\nin GBR initial partition is not valid!!!";
            return NULL;
        }
    }
    
    
    //double sum_mu = 0;
    //for (int i = 0; i < N; i++) sum_mu += mu[i];
    
    
    int num_shift = 0;
    int num_move2 = 0;
    
    std::cout <<"\n before local search sum_cost = " <<a*getGC(V)/sum_mu + (1-a)*get_geoCost(V)/kmean_cost_1cluster;
        
    for (int t = 0; t < n_iteration; t++){
        //std::cout <<"\nbefore: V[1] = ";
        //for (int v: V[1]) std::cout <<v <<" ";
        num_shift = shifting(V, a);
        //std::cout <<"\nafter: V[1] = ";
        //for (int v: V[1]) std::cout <<v <<" ";
        
        std::cout << "\nin local search t, num_shift, sum_cost = " <<t << " , " << num_shift << " ";
        std::cout <<a*getGC(V)/sum_mu + (1-a)*get_geoCost(V)/kmean_cost_1cluster;
        
//        num_move2 = move2(V);
//        std::cout << "\ninGBR() t, num_move2 = " <<t << ", " << num_move2;
        
        //std::cout <<"\nin GBR() t, num_shift, num_move = " << t << ", " << num_shift <<"," << num_move2;
        
        if ((num_move2 == 0) && (num_shift == 0))
            break;
    }
    
    
    
     //for output
    int* z = new int [N];
    for (int i = 0; i < N; i++) z[i] = -1;

    for (int s = 0; s < M; s++)
        for (int i: V[s])
            z[i] = s;
    /*
    std::cout << "\nchecking geo-diameter condition, geo-diameter: ";
    for (int s = 0; s < M; s++){
	std::cout <<"\nV[" <<s <<"]: size, geo-diameter: " <<V[s].size() << ", " << getgeo_diameter(V[s]);
    }
    */

    delete[] V;
    
    return z;
}





//------------------------------------


int algorithms::shifting(ivector* V, double a){
    
    double u[M], v[M];
    double omega[M], O[M];
    double f[M];
    int inCluster[N]; // inCluster[i] = j <=> vertex i is right now in cluster j
    
    double omega_geocost[M], O_geocost[M];
    
    
    for (int s = 0; s < M; s++){
        
        u[s] = 0; v[s] = 0;
        for(std::vector<int>::iterator it = V[s].begin(); it != V[s].end(); it++){
            u[s] += mu[*it];
            v[s] += sigma[*it] * sigma[*it];
            inCluster[*it] = s;

        }
        omega[s] = func(u[s] - kappa[s], sqrt(v[s] + gamma[s] * gamma[s])); //correct omega here
        omega_geocost[s] = get_geoWCCost(V[s]);
    }
    
    //double sum_mu = 0;
    
    //for (int i = 0; i < N; i++)
    //    sum_mu += mu[i];
    
//loop until no movement can be made
    int sum_num_move = 0;
int t;    
    for (t = 0; t < n_iteration; t++){
	int num_move = 0; 
        
        for (int i = 0; i < N; i++){
            
            int m = inCluster[i];
            //double s_star_diameter;
            
            O[m] = func(u[m] - mu[i] -kappa[m], sqrt(v[m] -sigma[i] * sigma[i] + gamma[m] * gamma[m]));
            O_geocost[m] = get_geoWCCcost_IfRemovePoint(V[m], i);
            
            double delta_star = 0;
            int s_star = m;//  rand() % M ;
            double delta;
            
            double delta_geo, delta_sum;
            
            for (int s = 0; s < M; s++){
                
                if (s == m)         continue;
                
                O[s] = func(u[s] + mu[i] - kappa[s], sqrt(v[s] + sigma[i] * sigma[i] + gamma[s] * gamma[s]));
                delta = omega[m] - O[m] + omega[s] - O[s];
            
                O_geocost[s] = get_geoWCCost_IfAddPoint(V[s], i);
                delta_geo = omega_geocost [m] + omega_geocost[s] - O_geocost[m] - O_geocost[s];
                
                delta_sum = a * delta/sum_mu + (1-a) * delta_geo/kmean_cost_1cluster;
                
                if (delta_sum > delta_star){
                
                    delta_star = delta_sum;
                    s_star = s; //we may move i from m to s_star
                    //s_star_diameter = tmp;
                }
            }
            if (s_star != m){                
                std::vector<int>::iterator pos = std::find(V[m].begin(), V[m].end(), i);
                
                V[m].erase(pos); //remove i from V[m]
                                
                V[s_star].push_back(i); //add i to V[s_star]
                
                
                u[m] = u[m] - mu[i];
                v[m] = v[m] - sigma[i] * sigma[i];
                omega[m] = O[m];

                u[s_star] += mu[i];
                v[s_star] += sigma[i] * sigma[i];
                omega[s_star] = O[s_star];
                inCluster[i] = s_star;
		num_move++;

                omega_geocost[m] = O_geocost[m];
                omega_geocost[s_star] = O_geocost[s_star];

                
            } //if (m # s_star)
            
            
        } //for i
        //std::cout <<"\nnorm_GC_cost/norm_geo_cost: ";
        //std::cout <<(getGC(V)/sum_mu) / (get_geoCost(V)/kmean_cost_1cluster);
	if (num_move == 0) {
            break;
        }
        sum_num_move += num_move;
        }
    //return sum_num_move;// - 1;
return t;
}




void algorithms::swap(int k, int* vertices, int* S, int* U, ivector* V){
    for (int i = 0; i < k; i++){
        if (S[i] == U[i]) {
            continue;
        }
        
        auto pos = std::find(V[S[i]].begin(), V[S[i]].end(), vertices[i]);

        if (pos != V[S[i]].end())                    
            V[S[i]].erase(pos); //remove vertice[i] from V[S[i]]

        V[U[i]].push_back(vertices[i]); //add vertice[i] to cluster V[U[i]]
    }
    
}

double algorithms::getGC(ivector* V){
    
    double gc = 0;
    for (int s = 0; s < M; s++){
        double u = 0;
        double v = 0;
        for (auto ele: V[s]){
            u += mu[ele];
            v += sigma[ele] * sigma[ele];
        }
        gc += func(u - kappa[s], sqrt(v + gamma[s] * gamma[s]));
    }
    return gc;
}

double* algorithms::getCentroid(std::vector<int> Vs){
    
    if (Vs.empty()) {
        return NULL;
    
    }
    double* ret = new double[2];
    
    
    int n = Vs.size();
    
    int p[n];
    int i = 0;
    for (int v: Vs){
        p[i] = v;
        i++;
    }
    
    double X = 0, Y = 0;
    for (int i = 0; i < n; i++){
        X += grid[p[i]][0];
        Y += grid[p[i]][1];        
    }
    ret[0] = X / double(n);
    ret[1] = Y / double(n);
    //std::cout <<"ret = " << ret[0] << "," <<ret[1];
    return ret;
}

double algorithms::get_geoWCCost(ivector Vs){
    //return geo_cost within cluster of Vs, see kmean objective function
    
    
    int n = Vs.size();
    double sum = 0;
    
    int p[n];
    int i = 0;
    for (int v: Vs){
        p[i] = v;
        i++;
    }
    
    double center[] = {0,0};
    
    double X = 0, Y = 0;
    for (int i = 0; i < n; i++){
        X += grid[p[i]][0];
        Y += grid[p[i]][1];        
    }
    center[0] = X / double(n);
    center[1] = Y / double(n);
    
    double dX, dY;
    for (int i = 0; i < n; i++){
       dX = (center[0] - grid[p[i]][0]);
       dY = (center[1] - grid[p[i]][1]);
       sum += dX * dX + dY * dY;
    }
    return sum;
    
}
double algorithms::get_geoWCCcost_IfRemovePoint(ivector Vs, int u){
    
    int n = Vs.size();
    if (n == 1) return 0;
    n = n - 1;
    double sum = 0;
    
    int p[n];
    int i = 0;
    for (int v: Vs){
        if (v == u) continue;
        p[i] = v;
        i++;
    }
    
    double center[] = {0,0};
    
    double X = 0, Y = 0;
    for (int i = 0; i < n; i++){
        X += grid[p[i]][0];
        Y += grid[p[i]][1];        
    }
    center[0] = X / double(n);
    center[1] = Y / double(n);
    
    double dX, dY;
    for (int i = 0; i < n; i++){
       dX = (center[0] - grid[p[i]][0]);
       dY = (center[1] - grid[p[i]][1]);
       sum += dX * dX + dY * dY;
    }
    return sum;
}
double algorithms::get_geoWCCost_IfAddPoint(ivector Vs, int u){
    
    int n = Vs.size() + 1;
    double sum = 0;
    
    int p[n];
    p[0] = u;
    int i = 1;
    for (int v: Vs){
        p[i] = v;
        i++;
    }
    
    double center[] = {0,0};
    
    double X = 0, Y = 0;
    for (int i = 0; i < n; i++){
        X += grid[p[i]][0];
        Y += grid[p[i]][1];        
    }
    center[0] = X / double(n);
    center[1] = Y / double(n);
    
    double dX, dY;
    for (int i = 0; i < n; i++){
       dX = (center[0] - grid[p[i]][0]);
       dY = (center[1] - grid[p[i]][1]);
       sum += dX * dX + dY * dY;
    }
    return sum;

}
double algorithms::get_geoCost(ivector* V){
    //return the geo_cost defined by kmean objective function
   
    double sum = 0; double t;
    for (int s = 0; s < M; s++){
        t = get_geoWCCost(V[s]);
        sum += t;
      
    }
    return sum;
    
}

double algorithms::get_allCost(ivector* V){
    return getGC(V) + get_geoCost(V);
}


int algorithms::con_localSearchPartition(std::string initFile, double a){
    
    ivector* V = NULL;
    std::cout <<"\nin LS: initFile = " <<initFile;
        
    if (initFile.empty()){
        std::cout <<"\ninitFile = " <<initFile <<" is EMPTY!";
        return 0;
    }else{
        
        V = initializeFByFile(initFile);
        
        if (V == NULL){
            std::cout <<"\ninitFile = " <<initFile;
            std::cout <<"\nin GBR initial partition is not valid!!!";
            return 0;
        }
    }
    
    int sum_iterations = 0;

    
    //std::cout <<"\n before local search sum_cost = " <<a*getGC(V)/sum_mu + (1-a)*get_geoCost(V)/kmean_cost_1cluster;
    int sum_num = 0;
    for (int t = 0; t < n_iteration; t++){
        int num_shift = shifting(V, a);

        
        if (num_shift == 0)
            break;
        sum_iterations += num_shift;
    }
    
    
    
     
    delete[] V;
    std::cout <<"\nsum_num_iterations: " <<sum_iterations;
    return sum_iterations;   
}