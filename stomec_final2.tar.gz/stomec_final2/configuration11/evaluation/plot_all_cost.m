%all_cost = GC + geo cost, mapping column = 
%kappa 1, gamma 2, a = 3 kmean = 4, metis = 5, GBR_kmean = 6, GBR_metis = 7

allcost = csvread("all_cost_M100.csv");  


%X => a
%Y => all_cost

% scatter on kmean, metis, GBR_kmean, GBR_metis

x = allcost(1:9, 3);


y_KM = allcost(1:9, 4);
y_MT = allcost(1:9, 5);
y_GBR_KM = allcost(1:9,6);
y_GBR_MT = allcost(1:9,7);


figure;
%plot(x, y_KM, 'LineWidth', 2);
%hold on;
plot(x, y_MT, 'LineWidth', 2);
hold on;
plot(x, y_GBR_KM, 'LineWidth', 2);
hold on;
plot(x, y_GBR_MT, 'LineWidth', 2);

%xlim([0 2]);


title ("Gaussian + geo cost, #clusters = 100, kappa = 1.5, gamma = 0.1")

legend ("METIS", "GBR/Kmean", "GBR/Metis");
xlabel("a ratio");
ylabel ("Gausian + geo cost");


