%EC_cost, mapping column = 
%kappa 1, gamma 2, a = 3, kmean = 4, metis = 5, GBR_kmean = 6, GBR_metis =
%7

%geo_cost mapping
%kappa = 1, gamma = 2, a = 3 kmean = 4, metis = 5, GBR_kmean = 6, GBR_metis = 7,


EC = csvread("EC_cost_M100.csv"); % kappa(1), gamma (2), 
geocost = csvread("geo_cost_M100.csv");

%X => geocost
%Y => ECcost

% scatter on kmean, metis, kmean_LS

max_geo = max(max(geocost(1:11, :))); % to scale

x_KM = geocost(1:11, 4)/max_geo;
x_MT = geocost(1:11, 5)/max_geo;
x_GBR_KM = geocost(1:11, 6)/max_geo;
x_GBR_MT = geocost(1:11, 7)/max_geo;

y_KM = EC(1:11, 4);
y_MT = EC(1:11, 5);
y_GBR_KM = EC(1:11,6);
y_GBR_MT = EC(1:11,7);

figure;
scatter(x_KM, y_KM, 50, 'filled');
hold on;
scatter(x_MT, y_MT, 50, 'filled');
hold on;
scatter(x_GBR_KM, y_GBR_KM, 15, 'filled');
%plot(x_GBR_KM, y_GBR_KM, 'LineWidth', 2);
hold on;
scatter(x_GBR_MT, y_GBR_MT, 15, 'filled');
%plot(x_GBR_MT, y_GBR_MT, 'LineWidth', 2);
%xlim([0 2]);


title ("EC & geo cost, #clusters = 100, kappa = 1.5, gamma = 0.1, a = [.1 -> .9]");

legend ("KMean", "METIS","GBR/KM", "GBR/MT");
xlabel("GEO cost");
ylabel ("Emperical cost");


